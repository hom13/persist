<?php
/*
* @Theme Name: Persist
* @Template Part: Footer
*/
;?>
<div class="clear"></div>
</div><!--.container-->
</div><!--.main-->
<footer class="site-footer">
<div class="wrapper"><!--wrapper-->
<div class="col-l-7">
</div>
<div class="copyright col-r-3"><p>&copy; <?php echo date("Y");?> <a href="<?php echo site_url();?>"> <?php echo bloginfo("title");
?> </a></p></div>
<div class="clear"></div>
</div><!--.wrapper-->
</footer>
<?php wp_footer();?>
</body>
</html>