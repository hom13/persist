<?php get_header();?>
<section class="tag entry-posts-grid col-l-7"><!--tag-->
<div class="meta"><!--meta-->
<div class="title">
<h1><?php single_tag_title();?>'s posts tags</h1>
</div>
<?php if(tag_description() != ""):?>
<div class="description">
<?php echo tag_description();?>
</div>
<?php endif;?>
</div><!--.meta-->
<div class="posts">
<?php
if(have_posts()):while(have_posts()):the_post();
get_template_part("template-parts/posts/content");
endwhile;
echo persist_paginate();
endif;?>
</div>
</section><!--.tag-->
<?php get_sidebar();?>
<?php get_footer();?>