<?php
/*
* @Theme Name: Persist
* @Template Part: Comments
*/
;?>
<section class="comments-container"><!--comments-->
<div class="comments-form-container">
<?php
$commenter = wp_get_current_commenter();
$req       = get_option("require_name_email");
$aria_req  = ($req ? "aria-required=\"true\"" : "");
//Comment fields
$fields = array(
    "author"  => "<div>\n
    <label for=\"author\">Name:</label>
    <input type=\"text\" name=\"author\" id=\"comment-author\" value=\"".
    esc_attr($commenter['comment_author'])."\" {$aria_req} required placeholder=\"".
    __("Name","persist")."\" size=\"30\"/>
    <p class=\"required-field\">Required field</p>
    </div>\n",
    "email"   => "<div>\n
    <label for=\"email\">E-mail:</label>
    <input type=\"mail\" name=\"email\" id=\"comment-email\" value=\"".
    esc_attr($commenter['comment_author_email'])."\" {$aria_req} required placeholder=\"".
    __("E-mail","persist")."\" size=\"30\"/>
    <p class=\"required-field\">Required field</p>
    </div>\n"
);
//Comments arguments
$comments_args = array(
    "class_form"     => "comment-form",
    "id_form"        => "comment-form",
    "label_submit"   => "Comment",
    "id_submit"      => "comment-submit",
    "class_submit"   => "comment-submit",
    "title_reply"    => "Leave your Comment",
    "comment_notes_before"  => "",
    "comment_notes_after"   => "",
    "title_reply_to" => "Reply",
    "comment_field"  => "<div>\n
    <textarea name=\"comment\" class=\"comment-field\" required placeholder=\"".
    __("Write yor comment..","persist")."\"></textarea>
    </div>\n",
    "fields"         => apply_filters("comment_form_default_fields",$fields)
);
if(comments_open()):
comment_form($comments_args);
else:?>
<div class="comments-closed">
<h2>Comments are now closed on this article</h2>
</div>
<?php endif;?>
</div>
<div class="comments-section">
<?php
if(comments_open() && get_comments_number()):
    $list_args = array(
        "style"       => "div",
        "avatar_size" => 120,
    );

    wp_list_comments($list_args);
;?>
<div class="comment-paginate">
<?php
$args = array(
    "prev_text" => "&laquo;",
    "next_text" => "&raquo;"
);
paginate_comments_links($args);
;?>
</div>
<?php
endif;
?>
</div>
</section><!--.comments-->