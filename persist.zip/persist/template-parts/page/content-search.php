<div class="post">
<div>
<div class="title">
<h3><a href="<?php the_permalink();?>"><?php the_title();?></a></h3>
</div>
<div class="content">
<?php the_excerpt();?>
</div>
</div>
</div>