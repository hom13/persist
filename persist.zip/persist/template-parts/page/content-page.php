<div class="post <?php the_ID();?>">
<div class="title"><h1><?php the_title();?></h1></div>
<?php if(has_post_thumbnail()):?>
<div class="thumbnail"><?php the_post_thumbnail();?></div>
<?php endif;?>
<div class="content">
<?php the_content();?>
</div>
<div class="meta">
<div>
<p>Last updated on <span><?php the_modified_date();?></span></p>
</div>
</div>
</div>