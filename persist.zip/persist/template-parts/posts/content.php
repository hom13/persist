<div class="post">
<div>
<div class="thumbnail">
<?php persist_edit_post();?>
<a href="<?php the_permalink();?>"><?php the_post_thumbnail();?></a>
</div>
<div class="content">
<div class="title"><a href="<?php the_permalink();?>"><?php the_title();?></a></div>
<div class="intro"><?php the_excerpt();?></div>
</div>
</div>
</div>