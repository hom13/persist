<div <?php post_class("post");?> id="<?php the_ID();?>">
<div class="title"><h1><?php the_title();?></h1></div>
<div class="meta">
<div>
<p>Posted on <span><?php the_date();?></span> by <span><?php the_author_posts_link();?></span> to <span><?php
the_category(", ");?></span></p>
</div>
</div>
<?php
if(has_post_thumbnail()):?>
<div class="thumbnail">
<?php the_post_thumbnail();?>
</div>
<?php
else:?>
<div class="no-thumbnail">
</div>
<?php endif;?>
<div class="content">
<?php the_content();?>
</div>
<?php persist_edit_post();?>
</div>