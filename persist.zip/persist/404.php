<?php get_header();?>
<div class="col-l-7 error-404">
<div class="wrap">
<h1>Error 404 page not found</h1>
<p>The page that you're try to access doens't exist or was moved.</p>
</div>
</div>
<?php get_sidebar();?>
<?php get_footer();?>