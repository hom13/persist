<?php
/*
* @Theme Name: Persist
* @Template part: Page
*/
;?>
<?php get_header();?>
<section class="page-article col-l-7">
<?php
if(have_posts()):while(have_posts()):the_post();
get_template_part("template-parts/page/content","page");
endwhile;endif;?>
</section>
<?php get_sidebar();?>
<?php get_footer();?>