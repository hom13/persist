<?php
/*
* @Theme Name: Persist
* @Template Part: Search
*/
;?>
<?php get_header();?>
<section class="entry-posts-list col-l-7"><!--search result-->
<div class="search-query">
<?php if(have_posts()):?>
<div class="query">
<h1><?php printf(__("Search result for: <span id=\"query-result\">%s</span>","persist"),get_search_query());?></h1>
</div>
<?php else:?>
<h1><?php _e("Nothing found matching your criteria","persist");?></h1>
<?php endif;?>
</div>
<div class="posts">
<?php if(have_posts()):while(have_posts()):the_post();?>
<?php get_template_part("template-parts/page/content","search");
endwhile;?>
<div class="site-paginate">
<div>
<?php echo persist_paginate();?>
</div>
</div>
<?php else:?>
<div class="search-query">
<p><?php _e("No post found, try search using another keyword(s)","persist");?></p>
<div class="search-form">
<?php get_search_form();?>
</div>
</div>
<?php endif;?>
</div>
</section><!--.search result-->
<?php get_sidebar();?>
<?php get_footer();?>