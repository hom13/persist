<?php
/*
* @Theme Name: Persist
* @Template Part: Author
*/
;?>
<?php get_header();?>
<section class="author-page entry-posts-list col-l-7"><!--author page-->
<?php
$author = (isset($_GET['author_name'])) ? get_user_by('slug',$author_name) : get_userdata(intval($author));
;?>
<div class="author-meta">
<h1><?php print $author->display_name;?>'s posts:</h1>
</div>
<?php
if(have_posts()):while(have_posts()):the_post();
get_template_part("template-parts/page/content","search");
endwhile;
;?>
<div class="site-paginate">
<div>
<?php
//Blog pagination
echo persist_paginate();
;?>
</div>
</div>
<?php endif;?>
</section><!--.author page-->
<?php get_sidebar();?>
<?php get_footer();?>