/*
* @Theme Name: Persist
* @Main blog js
*/
(function($){
var has_children = $(".primary-menu .menu-item-has-children");
has_children.prepend("<span class=\"arrow-down\">&#9207;</span>");
$(document).ready(function(){
    //Toggle Primary menu on mobile
    var toggleMenu = $(".show-menu #button");
    toggleMenu.click(function(){
        var parentButton = $(this).parents(".show-menu")
        parentButton.next(".primary-menu").slideToggle();
    })

    toggle_subMenu = $(".primary-menu .arrow-down");
    toggle_subMenu.click(function(){
        $(this).nextAll("ul").slideToggle();
    })
    //onresize window
    $(window).resize(function(){
        var winWidth, windHeight, primaryMenu;
        winWidth = $(window).width();
        primaryMenu = $(".primary-menu");
        if(winWidth > 768){
            primaryMenu.css("display","block");
            toggle_subMenu.nextAll("ul").css("display","");
        }else if(winWidth <=768){
            primaryMenu.css({
                "display":"none"
            })
        }
    })
})
})(jQuery);