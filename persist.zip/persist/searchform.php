<?php
/*
* @Theme Name: Persist
* @Template Part: Searchform
*/
;?>
<form action="<?php echo esc_url(site_url());?>" method="get" class="search-form" id="serach-form">
<input type="text" name="s" id="search-query" value="<?php the_search_query();?>" placeholder="Search"/>
<input type="hidden" name="post_type" id="post_type" value="post"/>
<button type="submit" class="search" id="search">search</button>
</form>
