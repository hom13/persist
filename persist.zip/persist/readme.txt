Theme Name: Persist
Theme URI: https://github.com/
Author Name: Herminio Orlando Machava
Author URI: https://github.com/
Description: Persist is an simple and responsive theme focused on bloging, news and entertainment blogs/websites
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

## Copyright ##
Persist Wordpress theme, copyright 2017 Herminio Orlando Machava
Persist Wordpress theme is licensed under the term of GNU General Public license

## Third Part frameworks ##

Persist come with the following third-party resource:

ShivHTML5, copyright
License: MIT
Source: https://github.com/

## Changelog ##

version alpha
inital release