<!DOCTYPE html>
<html <?php language_attributes();?>>
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0"/>
<?php wp_head();?>
<!--[if lt ie 9]>
<script src="<?php echo get_template_directory_uri()."/scripts/html5shiv.min.js";?>" type="text/javascript"></script>
<![endif]-->
</head>
<body <?php body_class();?>>
<header class="site-header">
<div class="header-menu-section"><!--header menu section-->
<div class="wrapper">
<div class="social-menu"><!--social menu-->
<div>
<a href="<?php echo !empty(get_option("facebook")) ? get_option("facebook") : "#";?>" id="facebook">
<span class="fa fa-facebook"></span>
</a>
<a href="<?php echo !empty(get_option("twitter")) ? get_option("twitter") : "#";?>" id="twitter">
<span class="fa fa-twitter"></span>
</a>
<a href="<?php echo !empty(get_option("google-plus")) ? get_option("google-plus") : "#";?>" id="google-plus">
<span class="fa fa-google-plus"></span>
</a>
</div>
</div><!--.social menu-->
<?php
if(has_nav_menu("header-menu")){
    wp_nav_menu(
        array(
            "theme_location"  => "header-menu",
            "container_class" => "header-menu"
        )
    );
}
;?>
<div class="clear"></div>
</div>
</div><!--.header menu section-->
<div class="headering"><!--headering-->
<?php
$text_color = get_header_textcolor();
;?>
<?php if(get_header_image()):?>
<div class="has-header-image">
<div class="header-image"><!--header image-->
<img src="<?php header_image();?>" width="<?php echo get_custom_header()->width;
?>" height="<?php echo get_custom_header()->height;?>">
</div><!--.header image-->
<div class="wrapper">
<div class="blog-meta" style="color:#<?php echo $text_color;?>;"><!--blog meta-->
<h1><a href="<?php echo esc_url(home_url());?>"><?php bloginfo("name");?></a></h1>
<p><?php bloginfo("description");?></p>
</div><!--.blog meta-->
</div>
</div>
<?php else:?>
<div class="no-header-image">
<div class="wrapper">
<div class="blog-meta" style="color:#<?php echo $text_color;?>;"><!--blog meta-->
<h1><a href="<?php echo esc_url(home_url());?>"><?php bloginfo("name");?></a></h1>
<p><?php bloginfo("description");?></p>
</div><!--.blog meta-->
</div>
</div>
<?php endif;?>
</div><!--.headering-->
<div class="menu-section">
<?php
//Blog primary nav bar
if(has_nav_menu('primary-menu')):?>
<div class="show-menu"><span id="button">&#9776;</span></div>
<?php
wp_nav_menu(
    array(
        "theme_location" => "primary-menu",
        "container_class" => "primary-menu wrapper",
        "menu_class" => null
        
    )
);
endif;
;?>
</div>
</header>
<div class="main"><!--main-->
<div class="container"><!--container-->