<?php
/*
* @Theme Name: Persist
* @Template Part: Single
*/
;?>
<?php get_header();?>
<section class="article col-l-7">
<?php
if(have_posts()):
$query = get_post();
while(have_posts()):the_post();
get_template_part("template-parts/posts/content","single");
endwhile;?>
<div class="post-tags">
<span class="">tags:</span>
<?php
//Post tags
the_tags("<span>",", ","</span>");
?>
</div>
<div class="prev-next-posts"><!--Prev Nex posts-->
<?php persist_nav_posts();?>
</div><!--.Prev Next posts-->
<?php
comments_template();
;?>
<?php endif;?>
</section>
<?php get_sidebar();?>
<?php get_footer();?>