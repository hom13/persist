<?php
/*
* @Theme Name: Persist
* @Template's Functions
*/
//Add some supoort the theme
function persist_supports(){
    add_theme_support("title-tag");
    add_theme_support("post-thumbnails");
    add_theme_support("automatic-feed-links");
    add_theme_support("content-width",1200);
    if(!isset($content_width))$content_width = 1200;

    $headers = array(
        "default" => array(
            "url"           => "%s/img/header.jpg",
            "thumbnail_url" => "%s/img/header.jpg",
            "description"   => "Default header image"
        )
    );
    register_default_headers($headers);

    $header_args = array(
        "default-image"      => get_template_directory_uri()."/img/header.jpg",
        "width"              => 1920,
        "height"             => 600,
        "uploads"            => true,
        "flex-width"         => true,
        "flex-height"        => true,
        "default-text-color" => "#FFF"
    );
    add_theme_support("custom-header",$header_args);
}
add_action("after_setup_theme","persist_supports");

//Blog/Site configurations
function persist_site_settings(){

    function show_at_most($query){
        $home = $cat_tag = "";
        if(!is_admin() && $query->is_main_query()):
            
            if(!empty(get_option("enable-posts-fields"))){
                $home    = get_option("home-posts");
                $cat_tag = get_option("cat-tag-posts");
                if(is_home()){
                    $query->set("posts_per_page",$home);
                }
                if(is_archive() || is_author() || is_category() || is_search() || is_tag()){
                    $query->set("posts_per_page",$cat_tag);
                }
            }

        endif;
    }
    add_filter("pre_get_posts","show_at_most");
}
add_action("after_setup_theme","persist_site_settings");
//Setup the theme nav menus
function persist_menus(){
    register_nav_menus(
        array(
            "primary-menu"       => __("Primary menu","persist"),
            "header-menu" => __("Header Menu","persist")
        )
    );
}
add_action('init','persist_menus');

//Including blog scripts and styles
function persist_scripts(){
    wp_register_style("style",get_template_directory_uri()."/style.css",false,null,false);
    wp_enqueue_style('style');
    wp_register_style("Open Sans",
    "https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800|Roboto:400,600,700|Lato:400,600,700",
    false,null,false);
    wp_enqueue_style("Open Sans");
    wp_register_style("Font Awesome",get_template_directory_uri()."/styles/font-awesome/css/font-awesome.min.css",
    false,null,false);
    wp_enqueue_style("Font Awesome");
    wp_register_script("jquery",includes_url()."/jquery.js",false,null,true);
    wp_enqueue_script("jquery");
    wp_register_script("site",get_template_directory_uri()."/scripts/site.js",false,null,true);
    wp_enqueue_script("site");
    if(is_singular()){
        wp_enqueue_script("comment-reply");
    }
}
add_action("wp_enqueue_scripts","persist_scripts");
//Format post excerpt
function persist_excerpt_length($length){
    return 18;
}
add_filter("excerpt_length","persist_excerpt_length");
function persist_excerpt_more($more){
    return sprintf(__("<a class=\"more\" href=\"%s\">read more</a>","persist"),get_the_permalink());
}
add_filter("excerpt_more","persist_excerpt_more");

//Blog pagination
function persist_paginate(){
    global $wp_query;
    $big = 999999999;
    $args = array(
        "base"      => str_replace($big,"%#%",esc_url(get_pagenum_link($big))),
        "format"    => "?page=%#%",
        "current"   => max(1,get_query_var('paged')),
        "total"     => $wp_query->max_num_pages,
        "mid_size"  => 1,
        "prev_next" => true,
        "prev_text" => "&laquo;",
        "next_text" => "&raquo;"
    );
    $html = "<div class=\"site-paginate\">\n<div>\n".paginate_links($args)."\n</div>\n</div>\n";
    if($args['total'] > 1)
    return $html;
}
function persist_link_pages(){
    $args = array(
        "before"      => "<div class=\"paginate-links\">",
        "after"       => "</div>",
        "echo"        => false,
    );
    return wp_link_pages($args);
}
//This function is used to register sidebar
function persist_sidebar(){
    $args = array(
        "name"          => sprintf(__("Right Sidebar","persist")),
        "id"            => "right-sidebar",
        "class"         => "right-sidebar",
        "description"   => "Add any widget that you want to be displayed on blog sidebar",
        "before_widget" => "<div class=\"widget\">\n",
        "after_widget"  => "</div>\n",
        "before_title"  => "<h4 class=\"title\">\n",
        "after_title"   => "</h4>\n"
    );
    register_sidebar($args);
}
add_action("widgets_init","persist_sidebar");

//Custom widget

//Edit post link
function persist_edit_post(){
    $query = get_post();
    $id = $type = $html = "";
    if(is_single() || is_page()){
        $id   = $query->ID;
        $type = $query->post_type;
    }elseif(is_home() || is_category() || is_tag() || is_author()){
        $id = $query->ID;
        $type = " ";
    }
    if(!empty($id) && !empty($type)){
        return edit_post_link("Edit $type","<div class=\"edit-post\"><span id=\"edit-post\">","</span></div>");
    }
}
//Next and Previous posts navigation function
function persist_nav_posts(){
    echo "<div>";
    echo "<ul>";
    echo "<li>";
    previous_post_link("<h4><span>&laquo;</span>%link</h4>","%title");
    echo "</li><li>";
    next_post_link("<h4>%link<span>&raquo;</span></h4>","%title");
    echo "</li>";
    echo "</ul>";
    echo "</div>";
}

/*
* Admin Settings
*/
//Custom theme page
function persist_admin_scripts(){
    if(!empty($_GET['page']) && $_GET['page'] == "theme-options"):
    wp_register_style("Theme Settings",get_template_directory_uri()."/styles/theme-options.css",false,null,false);
    wp_enqueue_style("Theme Settings");
    endif;
}
add_action("admin_enqueue_scripts","persist_admin_scripts");

//Social Media Settings output
function persist_settings_setup(){
    add_theme_page(__("Configure Theme Options","persist"),__("Theme Options","persist"),"manage_options",
    "theme-options","persist_settings_section");
}
add_action("admin_menu","persist_settings_setup");

//Social Medias sections fields
function facebook_field(){
;?>
<input type="text" name="facebook" id="facebook" value="<?php echo get_option("facebook");
?>" placeholder="e.g: https://facebook.com/mypage" />
<?php
}
function twitter_field(){
;?>
<input type="text" name="twitter" id="twitter" value="<?php echo get_option("twitter");
?>" placeholder="e.g: https://twitter.com/mypage" />
<?php
}
function google_plus_field(){
;?>
<input type="text" name="google-plus" id="google-plus" value="<?php echo get_option("google-plus");
?>" placeholder="e.g: https://plus.google.com/mypage" />
<?php
}
function meta_social_media(){
    _e("<p>Fill bellow fields with your social networks url's.</p>","persist");
}
//Social Media section
function persist_settings_fields(){
    add_settings_section("social-media",__("Configure Blog/Site Social Media","persist"),"meta_social_media",
    "theme-options");
    add_settings_field("facebook",__("Facebook URL:","persist"),"facebook_field","theme-options",
    "social-media",["label_for" => "facebook"]);
    add_settings_field("twitter",__("Twitter URL:","persist"),"twitter_field","theme-options","social-media",
    ["label_for" => "twitter"]);
    add_settings_field("google-plus",__("Google Plus URL:","persist"),"google_plus_field","theme-options",
    "social-media",["label_for" => "google-plus"]);
    register_setting("custom_options","facebook");
    register_setting("custom_options","twitter");
    register_setting("custom_options","google-plus");
}
add_action("admin_init","persist_settings_fields");

//Post per page
function __persist(){
    function enable_posts_fields(){
        ;?>
        <input type="checkbox" name="enable-posts-fields" id="enable-posts-fields" value="<?php
        echo !empty(get_option("enable-posts-fields")) ? get_option("enable-posts-fields") : "posts-enabled";
        ?>" <?php echo !empty(get_option("enable-posts-fields")) ? "checked=\"checked\"" : "";?>/>
        <?php
    }
    function home_posts_field(){
        ;?>
        <input type="number" name="home-posts" id="home-posts" min="1" value="<?php
        echo get_option("home-posts");?>" <?php echo empty(get_option("enable-posts-fields")) ? 
        "disabled=\"disabled\"" : "";?>/>
        <?php
    }
    function cat_tag_posts_field(){
        ;?>
        <input type="number" name="cat-tag-posts" id="cat-tag-posts" min="1" value="<?php
        echo get_option("cat-tag-posts");?>" <?php echo empty(get_option("enable-posts-fields")) ?
        "disabled=\"disabled\"" : "";?>/>
        <?php
    }
    function meta_posts_fields(){
        _e("<p>Configure the number of posts to show at the most on home, archives, author, categories and
        tags page.</p>","persist");
    }
    function __persist_section(){
        add_settings_section("posts-configure",__("Configure Posts","persist"),"meta_posts_fields",
        "theme-options");

        add_settings_field("enable-posts-fields","enable bellow options:","enable_posts_fields","theme-options",
        "posts-configure");
        add_settings_field("home-posts","home page:","home_posts_field","theme-options","posts-configure",
        array("label_for" => "home page"));
        add_settings_field("cat-tag-posts","archives, author, categories and tags page:","cat_tag_posts_field","theme-options",
        "posts-configure",array("label_for" => "cat tag pages"));

        register_setting("custom_options","enable-posts-fields");
        register_setting("custom_options","home-posts");
        register_setting("custom_options","cat-tag-posts");
    }
    add_action("admin_init","__persist_section");
}
add_action("init","__persist");

function persist_settings_section(){
;?>
<?php
//Message status on save settings
if(isset($_GET['settings-updated'])){
    add_settings_error("persist_settings_error","settings_error",__("Settings Saved","persist"),"updated");
    settings_errors("persist_settings_error");
}
;?>
<div class="wrap">
<h1></h1>
<div></div>
</div>
<div class="persist-header wrap">
<div>
<h1>Persist Theme options</h1>
</div>
</div>
<div class="persist-wrapper wrap">
<form action="options.php" method="post">
<div class="section"><!--section-->
<?php
settings_fields("posts_per_page");
settings_fields("custom_options");
do_settings_sections("theme-options");
;?>
</div><!--.section-->
<div>
<?php
submit_button("Update");
;?>
</div>
</form>
</div>
<?php
}