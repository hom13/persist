<?php
/*
* @Theme Name: Persist
* @Template Part: Sidebar
*/
;?>
<aside class="sidebar"><!--sidebar-->
<div>
<?php
if(is_active_sidebar("Right Sidebar")){
    dynamic_sidebar("Right Sidebar");
}
;?>
</div>
</aside><!--.sidebar-->