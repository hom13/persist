<?php get_header();?>
<div class="entry-posts-grid col-l-7"><!--.entry posts-->
<div class="posts">
<?php
if(have_posts()):while(have_posts()):the_post();
get_template_part("template-parts/posts/content");
endwhile;
//Pagination nav
echo persist_paginate();
endif;
;?>
<div class="clear"></div>
</div>
</div><!--.entry posts-->
<?php get_sidebar();?>
<?php get_footer();?>